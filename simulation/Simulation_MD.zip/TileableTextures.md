# Tile-able Textures

We'll make our own raster graphics tileable (seamless) for mapping to 3D shapes 

1. Take a picture of some texture with a little depth to it  
* [Concrete or plaster](https://media.freestocktextures.com/cache/55/74/557491c489317c2a5bb5604fc368d33e.jpg) is too flat, but [weathered wood](https://media.freestocktextures.com/cache/4a/84/4a84e06ebe710ba0212f07aac319cde7.jpg), with grooves and cracks would work  
Better would be [brick with mortar](https://media.freestocktextures.com/cache/9e/f2/9ef26762e6104b7837f1f06de1e9e597.jpg)  
A [stone wall](https://media.freestocktextures.com/cache/8d/2d/8d2d76bc3d3d915b0aa051559ef94d7e.jpg) would work or a [pebbled beach](https://media.freestocktextures.com/cache/fe/df/fedfd86d10a59e01e47f5adc46483718.jpg)   

> **Don't be fooled** by the fact that the above links are all to stock images, you must collect your own!  
Your best bet might be to take several images of each texture, and choose several different textures  

**Consider This:** 
You want, if I can put it this way, a sort of "regular chaotic" pattern —if there's a patch of moss in one corner, we'll have to mitigate that in processing as it will give the repetition of the image (tiling) away, spoiling the illusion! 

------

## Assignment: 
> You need to have collected some potential textures by Wednesday, August 28  
**Don't worry!** You can collect more after that!

------

You can begin to work on making your images seamless and tile-able in [photoshop with this tutorial](https://www.youtube.com/watch?v=mQLXH3HpYik) in any computer lab which has photoshop installed (Alumni 302, 309, 306 or CFA first floor)  

(On Wednesday, class time, I'll have a tutorial for some free photo editor which you can follow instead if you prefer)

> **Where We're Going:** [This is not a tutorial you'll have to follow](https://www.youtube.com/watch?v=43Ilra6fNGc), but an explanation of Bump, and Normal mapping (we may fool around with Displacement mapping just to get an understanding of it, but it's not great for games)

**Example Images for Tiling:**

* I've uploaded some images and tiled them —here's a link:

https://drive.google.com/drive/folders/1T-apFb8XTGByOIovOsCfwQ9qwGoKhty2?usp=sharing

* I created a video for each of these images, here's the playlist:

https://www.youtube.com/playlist?list=PLGrWy3Tx5u_tvfFqgDSWKM59aXa01prpn

> **Key thoughts:** 

* If you don't unlock the layer before resizing the Canvas, you'll lose information you may not want to lose

* Working with brick, your starting position is important: I started with a row of complete bricks followed by a row where the bricks are cut in half at both sides, etc

* The Clone Stamp tool is best used in little dribs and drabs, you can create whole objects with it or alter them —be aware that you can lower the "opacity" of the brush  

* I also use the Dodge and Burn tool to average our brightness and darkness

------

## Assignment: 
> Get to a lab with Photoshop (Alumni 302, 309 or Roessner 200, 202 are all good) and tile your photographed texture _and one other_ —yu can use one of mine, one of your own or one you find online but it must be made seamless by your efforts!

DUE MONDAY!

------

## Tiling Tutorials

> **NOTE:** Some of this next section was covered in Canvas Announcements. I'm brining it in here for your convenience

* You'll probably want to [install a fee student version of Maya and Mudbox](https://www.autodesk.com/education/edu-software/overview)

* A great [resource for finding out about Maya](https://help.autodesk.com/view/MAYAUL/2025/ENU/) (menus on the left, information buttons in the middle, keyword search upper right)

* Here are a couple of tutorials about creating materials with image textures and bump maps in Maya

1. [Materials with textures and bump maps](https://www.youtube.com/watch?v=Gy6jLBf6WWA)
2. [Bump map editing](https://www.youtube.com/watch?v=m2CAIeL07c4)

* Here's a pair of tutorials about creating textures in the UV editor and Photoshop
1. [Introduction](https://www.youtube.com/watch?v=zPinIjj_F8s)
2. [Useful example (crates)](https://www.youtube.com/watch?v=5Pc8eBxs0sY) 

## Assignment: 
> * **Follow the in-class tutorial** (or the "Materials with textures and bump maps" tutorials, above) to create materials with and without bump maps
> * **Experiment with bump maps of different kinds** with different height values, different shapes etc
> * **Create textures in the UV editor and Photoshop** (see the tutorials above)

We'll spend hour Friday studio hour troubleshooting these last tutorials and all of the above will be...

DUE MONDAY!

------

> **EXTRAS:** 
* Get my starting point Maya scene (we'll see how well this works) at [this google drive](https://drive.google.com/drive/folders/1pWxcGwoMBN_AhYSOsPs9a0MJ5d-DM7Op?usp=sharing), where I hope to share other items for the course

* You can get free textures, including normal and other maps at [AmbientCG](https://ambientcg.com/list?type=Material,Atlas,Decal) where all resources are [Creative Commons 0 Licensed](https://docs.ambientcg.com/license/)(public domain)

* Here's some [additional technique](https://www.youtube.com/watch?v=tvrlpsdPkwg&list=PLGrWy3Tx5u_tvfFqgDSWKM59aXa01prpn&index=5) which you might want to plug into what you've learned from the "Crates" UV tutorials, above 

------

## Hypershade Tutorials

Here's an introduction to the [Hypershade node editor](https://www.youtube.com/watch?v=jhEMvEGFehI) in Maya

It uses the Input / Output model, connecting modules with "wires" with which you may be familiar from other applications. If not, think of electronics, signal processing, anything that sends a signal, modulates it and outputs the result!

