# Modeling

## Topology

I'm assuming you've done _some_ modeling, either in Blender or Maya or some other program 

If you haven't yet, you'll eventually run into some issues of _topology_ which is a field of geometry but which, in our context, focuses on the wireframe which produces any particular shape

<img src="https://images.ctfassets.net/dqbqab5lm2pa/3ol6XDgtN4b6vc0UH0ZQTR/bc5a9b77ead077df5c211318d303b521/What_Are_Topology_And_Retopology_Of_3D_Models-2.jpg" alt="identical shapes with varying wireframes" style="width:600px">

It's important to know something about topology: 
<iframe width="560" height="315" src="https://www.youtube.com/embed/PvKzBThEsBM?si=pDIRfLD52oCYF86p" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

### Topological Problems
There are some common errors which can be avoided in production, a typical example is _pinching at the poles_, particularly of spheres

<img src="https://help.autodesk.com/cloudhelp/2022/ENU/Maya-Basics/images/GUID-A72125AA-6155-410E-955B-DBE334F23155.png" alt="distortion of texture map at the poles of a sphere" style="width:600px">

Even if this is not occurring we may not want pie shaped wedges of texture at the poles!

<img src="https://help.autodesk.com/cloudhelp/2022/ENU/Maya-Basics/images/GUID-FB48B11B-02C6-4D56-9E14-8B0E542E14CC.png" alt="pie shaped texture map at the poles of a sphere" style="width:600px">

------

> _If applied textures, shading or the results of subdivision appear weird on your model, your topology is the first thing to check!_

------

It's also important to know that topology issues _can be fixed_ —I've seen too many good models abandoned over topological issues! 

Maya has some tools to make this easier, though they may not always be the best approach... 

<iframe width="560" height="315" src="https://www.youtube.com/embed/1AfVBVuZtrQ?si=QKsDGzwPvzPrvQxF" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

### **Advanced Tips:** Common Issues and How to Avoid

The following come out of a Blender workflow but the concepts and techniques —the modeling _thinking_— all apply across the board:

<iframe width="560" height="315" src="https://www.youtube.com/embed/m8JkR6tI_q4?si=XPigX8gYXhw5fOJH&amp;start=100" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


